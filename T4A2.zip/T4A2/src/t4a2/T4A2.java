
package t4a2;

/**
 *
 * @author ioann
 */
import java.util.Scanner;
public class T4A2 {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Scanner obj=new Scanner (System.in);
        int menu,numero=0,mul=0,i=0,valor=0;
        String apodo="",reves = "";
        do {
        System.out.println("bienvenido , de acuerdo al siguiente menu , " + "\n1. tabla de multiplicacion del 1 al 10" + "\n2. numeros primos " + "\n3.pares e impares" + 
                "\n4imprimir una palabra  al reves . " + "\n5.salir");
        menu=obj.nextInt();
        
        switch (menu){
            case 1 :
                for (numero=1;numero<=10;numero++){
                    System.out.println("las tablas de multiplicar de " + numero);
                    
                    for (mul=0;mul<=10;mul++){
                        System.out.println( numero +" x " + mul + " = " + mul*numero);
                    }
                }
            break;
            case 2:
                System.out.println("por favor escriba un numero ");
                numero =obj.nextInt();
                for (i=1;i<numero;i++){
                    valor=0;
                    for (mul=1;mul<=i;mul++){
                       if (i%mul==0){
                        valor++;
                    }
                    }
                       if (valor==2){
                           System.out.println(i);
                       }
                       
                                    
                        
                    }
            break;
            case 3:
                System.out.println("por favor escriba un numero");
                numero=obj.nextInt ();
                 for (i=1;i<numero;i++){
                    if (i%2==0){
                        System.out.println( i  + " es par ");
                    } 
                    else {
                        System.out.println( i +" es impar ");
                    }
                     
                 }
                 break;
                 
            case 4:
                System.out.println("por favor ingrese la palabra que desee poner al reves ");
                apodo=obj.next();
                
                for (valor=apodo.length()-1;valor>=0;valor--){
                    reves =reves + apodo.charAt(valor);
                    
                }
                System.out.println(reves);
                break;
            case 5:
                System.out.println("gracias ");
                break;
            default:
                System.out.println("ingrese un valor adecuadamente");
                }
            
        
        }while (menu!=5);
        
        
        }
    
}
